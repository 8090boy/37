## 2.Define struct

xorm maps a struct to a database table, the rule is below.